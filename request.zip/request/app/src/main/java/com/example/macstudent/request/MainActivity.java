package com.example.macstudent.request;

import android.Manifest;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {


    //Dexter variables
    PermissionListener smsPermissionListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createPermissionListener();
    }

    public void createPermissionListener() {
        // a function to deal with permission

        // 1. check if the permisison listener variable is setup
        if (smsPermissionListener == null) {

            smsPermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                    // what should you do if person picks ALLOW
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage
                            ("4165694024", null, "hey, what's up?", null, null);

                    Log.d("hk", "SMS SENT!!!");
                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {


                    // what should you do if person picks DENY
                    Log.d("hk", "Person picked DENY, I can't send any messages!");
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {

                    // what should you do if permission is ALREADY set to DENY
                    // COPY AND PASTE FROM DEXTER - YOU DON"T EVEN NEED TO KNOW WHAT IT MEANS
                    token.continuePermissionRequest();
                }
            };
        }
        }


    public void smsbuttonPressed(View v)
    {
        Log.d("hk", "Button Pressed");
        //ask for permission
        //->dexter is automatically going to run the nonsense in the createpermissionlistener() function

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.SEND_SMS)
                .withListener(smsPermissionListener)
                .check();


    }
}
